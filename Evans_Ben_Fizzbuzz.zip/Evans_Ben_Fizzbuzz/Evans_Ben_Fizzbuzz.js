// <!-- For each number that is a multiple of 3, print "Fizz"
// For each number that is a multiple of 5, print "Buzz"
// For numbers which are a multiple of both 3 and 5, print "FizzBuzz"
// All other numbers should just print normally -->



for(var start=1; start <= 100;start++){
    if(start % 3 == 0 && start % 5 == 0){
        console.log("FizzBuzz");
    }
    else if(start % 3 == 0){
        console.log("Fizz")
    } else if (start % 5 == 0){
        console.log("Buzz")
    }
    else {
        console.log(start);
    }
}
