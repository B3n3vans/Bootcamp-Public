from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import flash
import re	# the regex module
from flask_app.models.user import User 
# create a regular expression object that we'll use later   
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


DATABASE = 'recipes_schema'

class Recipe:
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.instructions = data['instructions']
        self.description = data['description']
        self.under = data['under']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']
        # self.first_name = data['first_name']
        self.user = User

    @classmethod
    def save(cls, data):
        query = 'INSERT INTO recipes (name, instructions, description, under, created_at, updated_at, user_id) VALUES (%(name)s,%(instructions)s,%(description)s,%(under)s,NOW(),NOW(), %(user_id)s)'
        result = connectToMySQL(DATABASE).query_db(query,data)
        return result
    
    @classmethod
    def edit(cls, data):
        query = 'UPDATE recipes SET name = %(name)s, instructions = %(instructions)s, description = %(description)s WHERE id = %(id)s'
        result = connectToMySQL(DATABASE).query_db(query,data)
        return result

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes;"
        results =  connectToMySQL(DATABASE).query_db(query)
        recipes =[]
        for recipe in results:
            recipes.append(cls(recipe))
        return recipes
    
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM recipes WHERE id = %(id)s;"
        result = connectToMySQL(DATABASE).query_db(query,data)
        recipe = cls(result[0])
        return recipe
    
    @classmethod
    def delete(cls, data):
        query = "DELETE FROM recipes WHERE id = %(id)s"
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @classmethod
    def recipe_info(cls,data):
        query = "SELECT * FROM recipes JOIN users ON user_id = users.id WHERE recipes.id = %(id)s"
        results =  connectToMySQL(DATABASE).query_db(query,data)
        recipe = cls(results[0])
        return recipe
    
    @classmethod
    def get_one_by_user(cls,data):
        query = "SELECT * FROM recipes WHERE user_id = %(id)s;"
        result = connectToMySQL(DATABASE).query_db(query,data)
        recipe = cls(result[0])
        return recipe
    
    @staticmethod
    def validate_recipe(user):
        is_valid=True
        if len(user['name']) < 2:
            is_valid = False
            flash("Name must be atleast 3 characters")
        if len(user['description']) < 2:
            is_valid = False
            flash("description must be atleast 3 characters")
        if len(user['instructions']) < 2:
            is_valid = False
            flash("instructions section must be atleast 3 characters")
        return is_valid