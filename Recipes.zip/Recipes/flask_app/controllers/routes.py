from flask_app import app,render_template,bcrypt,redirect,request,session,flash
from flask_app.models.user import User
from flask_app.models.recipe import Recipe
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'first_name' not in session:
        return redirect('/')
    recipes = Recipe.get_all()
    return render_template('dashboard.html', recipes= recipes)

@app.route('/register',methods=['post'])
def register():
    # if 'first_name' not in session:
    #     return redirect('/')
    
        if not User.validate_user(request.form):
            return redirect('/')
        
        session['first_name']=request.form['first_name']
        
        hashed_pw = bcrypt.generate_password_hash(request.form['password'])
        data = {
            'first_name':request.form['first_name'],
            'last_name':request.form['last_name'],
            'email':request.form['email'],
            'password':hashed_pw
        }
        if User.check_email(data):
            flash("Email address is already registered!")
            return redirect('/')
        session['id']=User.save(data)
        return redirect('/dashboard')

@app.route('/login', methods=['post'])
def login():
    data = { "email" : request.form["email"] }
    user_exists = User.find_email(data)
    print(user_exists)
    if not user_exists:
        flash("Invalid Email/Password")
        return redirect("/")
    if not bcrypt.check_password_hash(user_exists.password, request.form['password']):
        flash("Invalid Email/Password")
        return redirect('/')
    session['first_name'] = user_exists.first_name
    session['id'] = user_exists.id
    return redirect("/dashboard")

@app.route('/create')
def create():
    if 'first_name' not in session:
        return redirect('/')
    return render_template('create.html')

@app.route('/new/<int:id>', methods=['POST'])
def createrecipe(id):
    id = session['id']
    if 'first_name' not in session:
        return redirect('/')
    data = {
        'name':request.form['name'],
        'description':request.form['description'],
        'instructions':request.form['instructions'],
        'under':request.form['under'],
        'created_at' : request.form['date_made'],
        'user_id' : id
        }
    print(data['created_at'])
    Recipe.save(data)
    
    return redirect('/dashboard')

@app.route('/recipe/<int:id>')
def recipes(id):
    if 'first_name' not in session:
        return redirect('/')
    data = {'id': id}
    recipe = Recipe.recipe_info(data)
    # person = Recipe.get_one_by_user(id)
    # person = User.info
    return render_template('recipe.html',recipe=recipe)



@app.route('/edit/<int:id>')
def edit(id):
    data = {'id': id}
    recipe = Recipe.get_one(data)
    return render_template('edit.html',recipe=recipe)

@app.route('/editform/<int:id>', methods=['post'])
def editform(id):
    if not Recipe.validate_recipe(request.form):
        return redirect(f'/edit/{id}')
    data = {
        'id':id,
        'name': request.form['name'],
        'description': request.form['description'],
        'instructions' : request.form['instructions']
        }
    Recipe.edit(data)
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    if 'first_name' not in session:
        return redirect('/')
    session.clear()
    return redirect('/')

@app.route('/delete/<int:id>')
def delete(id):
    if 'first_name' not in session:
        return redirect('/')
    data = {'id':id}
    Recipe.delete(data)
    return redirect('/dashboard')