import flask_app.controllers.routes
from flask_app import app


if __name__ == "__main__":
    app.run(debug=True)