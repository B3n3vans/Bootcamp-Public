from flask import Flask, render_template, url_for, request, redirect, session
# from multiprocessing import Value
import random
import operator

# ranNum = rand
app = Flask(__name__)
app.secret_key = 'keep a secret'
winners = []
player={}

@app.route('/reset')
def reset():
    rand = random.randint(1,100)
    print(rand, "reset")
    return rand


@app.route('/')
def home():
    session['attempt'] = 0
    session['num']=reset()
    session['diff'] =''
    print(session['num'], "session")
    return render_template('index.html')


@app.route('/guess', methods=['POST'])
def highlow():
    choice = request.form['guess']
    if 'difficulty' in request.form:
        difficulty = request.form['difficulty']
        session['diff'] = request.form['difficulty']
        print(difficulty)
    else:
        pass
    session['attempt'] = (int(session['attempt']+1))
    print(session['diff'])
    if session['diff'] == 'Hard':
        if session['attempt'] == 5:
            return render_template('/loser.html')
        else: 
            pass
    else:
        pass
    if int(choice) < session['num']:
        return redirect('/low')
    elif int(choice) > session['num']:
        return redirect('/high')
    else:
        return redirect('/winner')

@app.route('/high')
def high():
    return render_template('high.html')

@app.route('/low')
def low():
    return render_template('low.html')

@app.route('/winner')
def winner():
    # session['diff'] =''
    return render_template('winner.html')

@app.route('/leaderboard', methods=["POST","GET"])
def leaderboard():
    if request.method == 'GET':
        return render_template('/leaderboard.html')
    else:
        print(request.form)
        attempts = session['attempt']
        print(request.form['name'])
        name = request.form['name']
        print(name)
        player = {"attempts": attempts,"name":name,"difficulty":session['diff']}
        winners.append(player)
        print(player)
        print(winners)
        winners.sort(key=operator.itemgetter('attempts'))
        print(winners)
        return render_template('leaderboard.html',winners = winners, attempts = attempts)

# @app.route('/loser')
# def loser():
#     return render_template('/loser.html')

if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=8065)