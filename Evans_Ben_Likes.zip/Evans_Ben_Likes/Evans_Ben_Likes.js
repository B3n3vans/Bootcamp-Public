var like1 = document.querySelector("#likeable1");
var like2 = document.querySelector("#likeable2");
var like3 = document.querySelector("#likeable3");

var count1 = 9;
var count2 = 12;
var count3 = 9;

function callAlert1(){
    count1 ++;
    like1.innerText = count1 +" Like(s)";
}

function callAlert2(){
    count2 ++;
    like2.innerText = count2 +" Like(s)";
}

function callAlert3(){
    count3 ++;
    like3.innerText = count3 +" Like(s)";
}



// create var count2, count 1 then new functions to increment them 
// when the like button is pressed. also add the onclick and function to
//each of the buttons.