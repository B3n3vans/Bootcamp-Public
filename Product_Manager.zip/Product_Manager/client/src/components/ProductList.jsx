import React from 'react'
import {Link} from 'react-router-dom'
import axios from 'axios'
// import Details from '../view/Details'

const ProductList = (props) => {
    const {onDelete} = props
    // const [loaded, setLoaded] = useState(false)
    const handleDelete =(deleteId)=>{
        axios.delete(`http://localhost:8001/api/products/${deleteId}`)
          .then(response=>{
            console.log(response.data)
            props.onDelete(deleteId)
          })
          .catch(err=>console.log(err))
      }
    

  return (
    <div>
        <h1>All Products:</h1>
        {
        props.products?
        props.products.map((item,i)=>{
            return(
                <div>
                    <p key={i}><Link to={`/${item._id} `}>{item.title}</Link></p>
                    <button onClick={(e)=>handleDelete(item._id)}>Delete</button>
                </div>
            )
        }):
        <h3>Loading...</h3>
        }

    </div>
  )
}

export default ProductList