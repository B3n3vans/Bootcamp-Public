import React, {useEffect, useState} from 'react'
import {useParams, useNavigate} from 'react-router-dom'
import axios from 'axios'

const Update = () => {
    const [title, setTitle] = useState('')
    const [price, setPrice] = useState('')
    const [description, setDescription] = useState('')
    const {id} = useParams()
    const navigate = useNavigate()

    useEffect(()=>{
        axios.get(`http://localhost:8001/api/${id}`)
        .then(res=>{
            const product = res.data;
            setTitle(product.title);
            setPrice(product.price);
            setDescription(product.description);
            console.log(res.data)
        })
        .catch(err=>console.log(err))
    }, [])
    const handleSubmit=(e)=>{
        e.preventDefault();
        axios.patch(`http://localhost:8001/api/products/${id}`, {title, price, description})
          .then(response=>console.log(response.data))
          .catch(err=>console.log(err))
        navigate(`/${id}`)
      }

  return (
    <div>
        <h1> Update</h1>
        <form onSubmit={handleSubmit}>
            <label>Title: </label>
            <input type='text' value={title} name='title' onChange={(e)=>setTitle(e.target.value)}/><br />
            <label>Price: </label>
            <input type='text' value={price} name='price' onChange={(e)=>setPrice(e.target.value)}/><br />
            <label>Description: </label>
            <input type='text' value={description} name='description' onChange={(e)=>setDescription(e.target.value)}/><br />
            <input type='submit'/>
        </form>
    </div>
  )
}

export default Update