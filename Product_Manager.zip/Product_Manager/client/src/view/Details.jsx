import React,  {useState, useEffect} from 'react'
import {useParams, Link, useNavigate} from 'react-router-dom'
import axios from 'axios'

const Details = () => {
    const {id} = useParams()
    const [product, setProduct] = useState([])
    const navigate = useNavigate()

    useEffect(()=>{
        axios.get(`http://localhost:8001/api/${id}`)
        .then(res=>{
            console.log(res.data)
            setProduct(res.data)
        })
        .catch(err=>console.log(err))
    }, [])

    const handleDelete =(deleteId)=>{
        axios.delete(`http://localhost:8001/api/products/${deleteId}`)
          .then(response=>{
            console.log(response.data)
            navigate('/')
          })
          .catch(err=>console.log(err))
      }




  return (
        <div>
            <h1>{product.title}</h1>
            <p>Price: {product.price}</p>
            <p>Description: {product.description}</p>
            <Link to='/'>Home</Link><br />
            <Link to={`/${product._id}/edit`}>Edit</Link><br />
            <button onClick={(e)=>handleDelete(product._id)}>Delete</button>
        </div>
  )
}

export default Details