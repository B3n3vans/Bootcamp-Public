import React, {useState, useEffect} from 'react'
// import Form from './components/Form';
import axios from 'axios'
import ProductList from '../components/ProductList';
import Form from '../components/Form';

const Main = () => {
    const [products, setProducts] = useState([])
    useEffect(()=>{
        axios.get('http://localhost:8001/api/products')
        .then(res=>{
            console.log(res.data)
            setProducts(res.data)
            // setLoaded(true)
        })
        .catch(err=>console.log(err))
    }, [])

    const addToDom = (newProduct)=>{
        setProducts([...products, newProduct])
    }
    const removeFromDom = (deleteId) =>{
        const filteredList = products.filter((item)=>item._id != deleteId)
        setProducts(filteredList)
      }

  return (
    <div>
      <h1>Product Manager</h1>
        <Form onCreate={addToDom}/>
        <ProductList products={products} onDelete={removeFromDom}/>
        {/* {props.children} */}
    </div>
  )
}

export default Main