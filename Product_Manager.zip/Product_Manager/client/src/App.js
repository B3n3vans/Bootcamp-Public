// import logo from './logo.svg';
import './App.css';


import {Routes,Route} from 'react-router-dom';
import Details from './view/Details';
import Main from './view/main';
import Update from './view/Update';

function App() {
  return (
    <div className="App">

      <Routes>
        <Route path='/' element={<Main />}/>
        <Route path='/:id' element={<Details />}/>
        <Route path='/:id/edit' element={<Update />}/>
      </Routes>
    </div>
  );
}

export default App;
