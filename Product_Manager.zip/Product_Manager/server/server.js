const express = require('express');
const app = express();
const cors = require('cors')
require('dotenv').config();

require('./configs/mongoose.config')

app.use(cors())
app.use(express.json());          //
app.use(express.urlencoded({extended:true}));

const Router = require('./routes/productManager.routes');
Router(app);


app.listen(8001, ()=>console.log('listening to the port: 8001'));
