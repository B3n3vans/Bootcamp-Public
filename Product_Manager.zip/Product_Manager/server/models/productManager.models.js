const mongoose = require('mongoose');
const DestinationSchema = new mongoose.Schema({
    title: {
        type:String,
        required:[true, 'Title is required'],
        minlength: [2, 'Title must be at least 2 characters long']
    },
    price:{
        type:Number,
        required:[true, 'Price is required'],
        min : [0,"Price must be greater than 0"]
    },
    description:{
        type: String,
        required:[true, 'Please insert a description']
    }


}, {timestamps : true})

module.exports = mongoose.model('Destination',DestinationSchema)