const PMController = require('../controllers/productManager.controller')

module.exports = (app)=>{
    app.get('/api/testing', PMController.apiTest);
    app.get('/api/products', PMController.allProduct);
    app.get('/api/:id', PMController.oneProduct);
    app.post('/api/products', PMController.addProduct);
    app.patch('/api/products/:id', PMController.updateProduct);
    app.delete('/api/products/:id', PMController.deleteProduct);
}