import React, {useEffect, useState} from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
import CreateForm from '../components/createForm'
import AuthorsTable from '../components/AuthorsTable'

const Main = () => {
    const [authorList, setAuthorList] = useState([])
    const navigate = useNavigate()
    useEffect(()=>{
        axios.get('http://localhost:8003/api/authors')
        .then(response=>{
          setAuthorList(response.data)
            console.log(response.data)
        })
        .catch(err=>console.log(err))
    }, [])


const removeFromDom = (deleteId) =>{
  const filteredList = authorList.filter((eachDest)=>eachDest._id != deleteId)
  setAuthorList(filteredList)
}

const addToDom = (newDest) =>{
  setAuthorList([...authorList, newDest])
}


  return (
    <div>
      <p><Link to='/create'>Add an Author</Link></p>
      <AuthorsTable authorList={authorList} onDelete={removeFromDom}/>
    </div>
  )
}

export default Main