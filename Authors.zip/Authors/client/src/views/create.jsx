import React, {useState} from 'react'
import {Link} from 'react-router-dom'
import axios from 'axios'
import CreateForm from '../components/createForm'

const Create = () => {



  return (
    <div>
      <Link to='/'> Home </Link>
      <CreateForm />
    </div>
  )
}

export default Create