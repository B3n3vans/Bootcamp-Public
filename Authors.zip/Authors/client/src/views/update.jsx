import React, {useState, useEffect} from 'react'
import {useParams, useNavigate, Link} from 'react-router-dom'
import axios from 'axios'

const Update = () => {
  const [name, setName] = useState('')
  const [errors, setErrors] = useState([])
  const navigate = useNavigate()
  const {id} = useParams()

  useEffect(()=>{
    axios.get(`http://localhost:8003/api/authors/${id}`)
      .then(response =>{
        const res = response.data
        setName(res.name);
        console.log(res.name)
      })
      .catch(err=> console.log(err))
  },[])
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.patch(`http://localhost:8003/api/${id}/edit`, {name})
      .then(response=>{
        console.log(response.data)
        navigate(`/authors/${id}`)
      })
      .catch(err=>{
        console.log(err.response.data.errors.name.message)
        setErrors(err.response.data.errors.name.message)
      })
  }



  return (
    <div>
      
      <form onSubmit={handleSubmit}>
            <div>
                <label> Name</label>
                <input type='text' name='name' value={name}
                onChange={e=>setName(e.target.value)}/>
            </div>
            <button>Submit</button>
        </form>
        {
          errors&&
          <p style={{color:'red'}}>{errors}</p>
        }
        <button><Link to='/'> Cancel </Link></button>
      </div>
  )
}

export default Update