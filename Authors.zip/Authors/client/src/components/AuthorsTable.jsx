import React from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

const DestTable = (props) => {


    const handleDelete =(deleteId)=>{
        axios.delete(`http://localhost:8003/api/authors/${deleteId}`)
          .then(response=>{
            console.log(response.data)
            props.onDelete(deleteId)
          })
          .catch(err=>console.log(err))
      }
    //   const removeFromDom = (deleteId) =>{
    //     const filteredList = destList.filter((eachDest)=>eachDest._id != deleteId)
    //     setDestList(filteredList)
    //   }



  return (
    <div>
      <p>We have quotes by: </p>
        <table>
        <thead>
          <tr>
            <th>Author</th>
            <th>Actions available</th>
          </tr>
        </thead>
        <tbody>
          {props.authorList&&
            props.authorList.map((eachAuthor, idx)=>{ 
              return(
              <tr key={idx}>
                <td>{eachAuthor.name}</td>
                <td>
                  <Link to={`/authors/${eachAuthor._id}`}>
                  {eachAuthor.location}</Link>
                  <button><Link to={`/edit/${eachAuthor._id}`}>Edit</Link></button>
                  <button onClick={ ()=>handleDelete(eachAuthor._id)}>Delete</button>
                </td>
              </tr>
              )})} 
        </tbody>
      </table>
    </div>
  )
}

export default DestTable