import React, {useState} from 'react'
import axios from 'axios'
import {useNavigate, Link} from 'react-router-dom'
const CreateForm = (props) => {
    const [name, setName] = useState('')
    const [errors, setErrors] = useState([])
    const navigate = useNavigate()

    const handleSubmit=(e)=>{
        e.preventDefault()
        axios.post('http://localhost:8003/api/authors',{name})
        .then(response =>{
            console.log(response.data)
            // props.onCreate(response.data)
            navigate('/')
        })
        .catch(err=>{
            const errResponse = err.response.data.errors;
            const errMsgArr = []
            for(const eachKey in errResponse){
                errMsgArr.push(errResponse[eachKey]['message'])
                console.log(errMsgArr)
            }
            setErrors(errMsgArr)
        })
    }

  return (
    <div>
        <p> Add a New Author:</p>
        <form onSubmit={handleSubmit}>
            <div>
                <label> Name </label>
                <input type='text' name='name' value={name}
                onChange={e=>setName(e.target.value)}/>
            </div>
            <button><Link to='/'>Cancel</Link></button>
            <button>Submit</button>
            {
                errors.map((eachErr, i)=>(
                        <p style={{color:'red'}} key={i}>{eachErr}</p>
                    )
                )
            }
        </form>
    </div>
  )
}

export default CreateForm