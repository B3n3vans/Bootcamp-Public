const AuthorController = require('../controllers/Authors.controller')

module.exports = (app)=>{
    app.get('/api/testing', AuthorController.apiTest);
    app.get('/api/authors', AuthorController.allAuthor);
    app.get('/api/authors/:id', AuthorController.oneAuthor);
    app.post('/api/authors', AuthorController.addAuthor);
    app.patch('/api/:id/edit', AuthorController.updateAuthor);
    app.delete('/api/authors/:id', AuthorController.deleteAuthor);
}