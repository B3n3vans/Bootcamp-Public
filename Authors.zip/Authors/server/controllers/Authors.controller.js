const Author = require('../models/Authors.models')

//test api route
module.exports.apiTest = (req, res)=>{
    res.json({message: 'ok'})
}
// all Authors
module.exports.allAuthor = (req, res)=>{
    Author.find()
        .then(authorList => res.json(authorList))
        .catch(err=>res.status(400).json(err))
}
//one Author
module.exports.oneAuthor = (req, res)=>{
    Author.findOne({_id:req.params.id})
    .then(foundAuthor => res.json(foundAuthor))
    .catch(err=>res.status(400).json(err))
}
//create Author
module.exports.addAuthor = (req, res)=>{
    Author.create(req.body)
        .then(newAuthor => res.json(newAuthor))
        .catch(err=>res.status(400).json(err))
}
// update Author
module.exports.updateAuthor = (req, res)=>{
    Author.findOneAndUpdate(
        {_id: req.params.id}, // criteria
        req.body, // formData
        {new: true, runValidators: true}
        //new: true -- return the updated object
        // runValidator -- to perform validation specified in model
    )
    .then(updatedAuthor=>res.json(updatedAuthor))
    .catch(err=>res.status(400).json(err))
}
//delete Authormodule.exports.apiTest = (req, res)=>{
module.exports.deleteAuthor = (req, res)=>{
    Author.deleteOne({_id: req.params.id})
    .then(status=>res.json(status))
    .catch(err=>res.status(400).json(err))
}