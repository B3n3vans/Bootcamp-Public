var screen = document.querySelector('.screen');
let display = document.querySelector('.full-problem');

var equation='';

const screenNum = (n) => {
    equation = equation += n;
    screen.innerText = equation;
    display.innerText = equation
    console.log(equation);
}

var calculatingEachNumberPressed = () => {
    var solution = eval(equation)
    screen.innerText = solution;
    equation = solution;
}

var cleanUp = () => {
    console.log("clear")
    equation = '';
    screen.innerText = equation;
}
var addShadow = (element) => {
    element.classList.add("shadow");
}
var removeShadow = (element) => {
    element.classList.remove("shadow");
}