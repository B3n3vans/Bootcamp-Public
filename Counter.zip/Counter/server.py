from flask import Flask, render_template, request, redirect, session
# import js2py
app = Flask(__name__)
app.secret_key = "keepsafe"


@app.route('/', methods=['POST','GET'])
def home():
    if 'key_name' in session:
        print('key exists!')
        print(session['key_name'])
        session['count'] = (session['count']+1)
        session["key_name"]=(session['key_name']+1)
    else:
        print("key 'key_name' does NOT exist")
        session['count'] = 1
        session["key_name"] = 1
    return render_template('index.html')

@app.route('/increment', methods=['POST'])
def Increment():
    # print(session['increment'])
    Increment = request.form['increment']
    session["key_name"] += (int(Increment)-1)
    return redirect('/')

@app.route('/num')
def showNum():
    session["key_name"] += 1
    return redirect('/')

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    session["key_name"] = 0
    session['count'] = 0
    return redirect('/')

# @app.route('/<x>/<y>')
# def adjusted(x,y):
#     return render_template('index.html', width = (int(y)), height = int(x))

# @app.route('/<x>/<y>/<color1>/<color2>')
# def colors(x,y,color1, color2):
#     return render_template('index.html', width = int(y), height = int(x), color1 = color1, color2 = color2)

if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=8055)