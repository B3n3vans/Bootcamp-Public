package com.codingdojo.bookclub.services;

import java.util.List;
import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.codingdojo.bookclub.models.LoginUser;
import com.codingdojo.bookclub.models.User;
import com.codingdojo.bookclub.repos.UserRepository;


@Service
public class UserService {
	 @Autowired
	 private UserRepository userRepo;
	 
	 public User register(User newUser, BindingResult result) {
		 Optional<User> optionalUser = userRepo.findByEmail(newUser.getEmail());
		 if (optionalUser.isPresent()) {
			 result.rejectValue("email", "unique", "Email is already registered.");
		 }
		 if (!newUser.getPassword().equals(newUser.getConfirm())) {
			 result.rejectValue("confirm", "unique", "Password and Confirm PW must match.");
		 }
		 if(result.hasErrors()) {
			 return null;
		 }
		 String hashed = BCrypt.hashpw(newUser.getPassword(),BCrypt.gensalt());
		 newUser.setPassword(hashed);
		 
		 return userRepo.save(newUser);
	 }
	 
	 
	 public User login(LoginUser newLogin, BindingResult result) {
		 
		 Optional<User> optionalUser = userRepo.findByEmail(newLogin.getEmail());
		 if (!optionalUser.isPresent()) {
			 result.rejectValue("email", "unique", "Please register");
		 }
		 
		 if(result.hasErrors()) {
			 return null;
		 }
		 
		 User user = optionalUser.get();
		 if (!BCrypt.checkpw(newLogin.getPassword(), user.getPassword())) {
			 result.rejectValue("password", "Matches", "Invalid Password!");
		 }
		 if (result.hasErrors()) {
			 return null;
		 }
		 return user;
	 }
	 
	 
	 public User save(User user) {
		 return userRepo.save(user);
	 }
	 public List<User> getAllUsers(){
		 return userRepo.findAll();
	 }
	 public User getOneUser(Long id) {
		 return userRepo.findById(id).orElse(null);
	 }
	
}