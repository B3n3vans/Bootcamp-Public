package com.codingdojo.bookclub.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.bookclub.models.Book;
import com.codingdojo.bookclub.repos.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository brepo;
	
	public Book save(Book book) {
		return brepo.save(book);
	}
	public List<Book> getAllBooks(){
		return brepo.findAll();
	}
	public Book getOneBook(Long id) {
		Optional<Book> optBook = brepo.findById(id);
		if(optBook.isPresent()) {
			return optBook.get();
		}else {
			return null;
		}
	}
	public void deleteOneBook(Long id) {
		brepo.deleteById(id);
	}
	
}
