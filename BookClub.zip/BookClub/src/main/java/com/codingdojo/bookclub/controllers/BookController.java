package com.codingdojo.bookclub.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.codingdojo.bookclub.models.Book;
import com.codingdojo.bookclub.services.BookService;
import com.codingdojo.bookclub.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class BookController {
	
	@Autowired
	private BookService bserv;
 
	@Autowired
	private UserService userv;
	
	@GetMapping("/books/new")
	public String createBook(@ModelAttribute("newBook") Book book, HttpSession session) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		return "createBook.jsp";
	}
	
	@PostMapping("/books")
	public String handleCreateBook(@Valid @ModelAttribute("newBook")Book book, BindingResult result, Model model) {
		if(result.hasErrors()) {
			return "createBook.jsp";
		}
		bserv.save(book);
		return "redirect:/dashboard";
	}
	@GetMapping("/books/{id}")
	public String oneBook(@PathVariable("id") Long id, @ModelAttribute("oneBook") Book book, HttpSession session, Model model) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		model.addAttribute("book", bserv.getOneBook(id));
		return "oneBook.jsp";
	}
	@GetMapping("/books/{id}/edit")
	public String editBook(@PathVariable("id") Long id, @ModelAttribute("editBook") Book book, HttpSession session, Model model) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		model.addAttribute("bookToEdit", bserv.getOneBook(id));
		return "editBook.jsp";
	}
	@PutMapping("/books/edit")
	public String handleBookEdit(@Valid @ModelAttribute("bookToEdit") Book book, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("bookToEdit", book);
			return "editBook.jsp";
		}
		Book editedBook = bserv.save(book);
		return "redirect:/books/" + editedBook.getId();
	}
	
	
	
	
	
	
	
	@DeleteMapping("/books/{id}")
	public String deleteBook(@PathVariable("id") Long id) {
		bserv.deleteOneBook(id);
		return "redirect:/dashboard";
	}
	
}


















