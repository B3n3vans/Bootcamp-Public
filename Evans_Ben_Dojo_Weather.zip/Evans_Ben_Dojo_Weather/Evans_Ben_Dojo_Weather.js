function loading(){
    alert("Loading weather report...");
}

var bye = document.querySelector(".button");
function dismiss(){
    bye.parentNode.remove();
}
var deg = document.querySelector(".deg");
var deg2 = document.querySelector(".deg2");
var deg3 = document.querySelector(".deg3");
var deg4 = document.querySelector(".deg4");
var deg5 = document.querySelector(".deg5");
var deg6 = document.querySelector(".deg6");
var deg7 = document.querySelector(".deg7");
var deg8 = document.querySelector(".deg8");

function changeDeg(element){
    if (element.value == "fahrenhiet"){
        deg.innerText = "75"
        deg2.innerText = "64"
        deg3.innerText = "81"
        deg4.innerText = "66"
        deg5.innerText = "70"
        deg6.innerText = "61"
        deg7.innerText = "79"
        deg8.innerText = "70"
    } else {
        deg.innerText = "24"
        deg2.innerText = "18"
        deg3.innerText = "27"
        deg4.innerText = "19"
        deg5.innerText = "21"
        deg6.innerText = "16"
        deg7.innerText = "26"
        deg8.innerText = "21"
    }
}
