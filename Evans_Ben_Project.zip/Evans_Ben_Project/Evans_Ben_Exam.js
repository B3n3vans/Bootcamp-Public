var takeAway = document.querySelector(".button")

function removeAd(element){
    element.parentNode.parentNode.remove();
}

function cartAlert(){
    alert("Your Cart is empty!");
}

var imgSwitch = document.querySelector("#pic1");
function imgChange(){
    imgSwitch.src = "succulents-2.jpg"
    imgSwitch.alt = "images of small pots of plants"
}
function imgBack(){
    imgSwitch.src = "succulents-1.jpg"
    imgSwitch.alt = "images of small pots of plants"
}
