import React, {useState} from 'react'
import axios from 'axios'
import './App.css';


function App() {
  const [pokemonList, setPokemonList] = useState([])


const fetchPokemon = async()=>{
  try{
      const response = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=807&offset=0')
      const list = response.data.results
      setPokemonList(list);
  console.log(pokemonList)
  }catch(err){
      console.log('.catch')
      setPokemonList(null);
  }
}

  return (
    <div className="App">
      <div>
        <h1> Pokemons</h1>
        <button onClick={fetchPokemon}> Fetch Pokemon</button>
      <ul className='flex'>
        {pokemonList.map((item, i)=>{
          return(
            <li className='box' key={i}>{item.name}</li>
          )
        })}
      </ul>
        
    </div>
    </div>
  );
}

export default App;
