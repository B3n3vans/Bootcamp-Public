from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import flash
import re	# the regex module
# create a regular expression object that we'll use later   
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


DATABASE = 'emails'

class Email:
    def __init__(self,data):
        self.id = data['id']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    
    @classmethod
    def save(cls,data):
        query = 'INSERT INTO emails (email, created_at, updated_at) VALUES(%(email)s,NOW(),NOW())'
        result = connectToMySQL(DATABASE).query_db(query,data)
        return result

    @classmethod
    def deleteemail(cls,data):
        query = 'DELETE FROM emails WHERE id = %(id)s'
        return connectToMySQL(DATABASE).query_db(query,data)

    @classmethod
    def get_all(cls):
        query = 'SELECT * FROM emails'
        allEmails = connectToMySQL(DATABASE).query_db(query)
        emails = []
        for email in allEmails:
            emails.append(cls(email))
        return emails
    
    @classmethod
    def find_email(cls,data):
        query = 'SELECT * FROM emails WHERE email = %(email)s'
        return connectToMySQL(DATABASE).query_db(query,data)

    @staticmethod
    def validate_email(user):
        is_valid=True
        if not EMAIL_REGEX.match(user['email']): 
            flash("Email address is not Valid!")
            is_valid = False
        
        return is_valid
    
        # query = 'SELECT * FROM emails'
        # allEmails = connectToMySQL(DATABASE).query_db(query)
        # emails = []
        # for email in allEmails:
        #     emails.append(cls(email))
        #     if user['email'] == cls(email['email']):
        #         flash("Email address is already registered!")
        #         is_valid = False