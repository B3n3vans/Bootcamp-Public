from flask_app import app,render_template,redirect,request,flash,session
from flask_app.models.email import Email

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/email', methods=['post'])
def email():
    if not Email.validate_email(request.form):
        return redirect('/')
    
    data = {'email': request.form['email']}
    session['email'] = data['email']
    if Email.find_email(data):
        flash("Email address is already registered!")
        return redirect('/')
    Email.save(data)
    return redirect('/emails')

@app.route('/emails')
def emaillist():
    emails = Email.get_all()
    return render_template('profile.html', emails = emails)

@app.route('/delete/<int:id>')
def delete(id):
    data = {'id': id}
    Email.deleteemail(data)
    return redirect('/emails')