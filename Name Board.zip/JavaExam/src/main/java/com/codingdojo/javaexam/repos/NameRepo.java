package com.codingdojo.javaexam.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.codingdojo.javaexam.models.Name;

public interface NameRepo extends CrudRepository<Name, Long>{
List <Name> findAll();
}
