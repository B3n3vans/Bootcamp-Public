package com.codingdojo.javaexam.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.javaexam.models.Name;
import com.codingdojo.javaexam.repos.NameRepo;

@Service
public class NameService {

	@Autowired
	private NameRepo nrepo;
	
	public Name save(Name name) {
		return nrepo.save(name);
	}
	public List<Name> getAllNames(){
		return nrepo.findAll();
	}
	public Name getOneName(Long id) {
		Optional<Name> optName = nrepo.findById(id);
		if (optName.isPresent()) {
			return optName.get();
		}else {
			return null;
		}
	}
	
	
	public void deleteOneName(Long id) {
		nrepo.deleteById(id);
	}
	
	
}
