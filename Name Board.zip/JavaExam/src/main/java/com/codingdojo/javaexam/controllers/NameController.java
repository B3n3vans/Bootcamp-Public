package com.codingdojo.javaexam.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.codingdojo.javaexam.models.Name;
import com.codingdojo.javaexam.services.NameService;
import com.codingdojo.javaexam.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;



@Controller
public class NameController {
	@Autowired
	private NameService nserv;

	
	@GetMapping("/names/new")
	public String createName(@ModelAttribute("newName") Name name, HttpSession session) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		return "createName2.jsp";
	}
	@PostMapping("/names")
	public String handleCreateName(@Valid @ModelAttribute("newName")Name name, BindingResult result, Model model) {
		if(result.hasErrors()) {
			return "createName2.jsp";
		}
		nserv.save(name);
		return "redirect:/dashboard";
	}
	
	@GetMapping("/names/{id}")
	public String oneName(@PathVariable("id") Long id, @ModelAttribute("oneName") Name name, HttpSession session, Model model) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		model.addAttribute("name", nserv.getOneName(id));
		return "oneName2.jsp";
	}
	
	@GetMapping("/names/{id}/edit")
	public String editName(@PathVariable("id") Long id, @ModelAttribute("editName") Name name, HttpSession session, Model model) {
		if (session.getAttribute("userId") == null) {
			session.invalidate();
			return "redirect:/";
		} 
		model.addAttribute("nameToEdit", nserv.getOneName(id));
		return "editName2.jsp";
	}
	@PutMapping("/names/edit")
	public String handleNameEdit(@Valid @ModelAttribute("nameToEdit") Name name, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("nameToEdit", name);
			return "editName2.jsp";
		}
		Name editedName = nserv.save(name);
		return "redirect:/names/" + editedName.getId();
	}
	
	@DeleteMapping("/names/{id}")
	public String deleteName(@PathVariable("id") Long id) {
		nserv.deleteOneName(id);
		return "redirect:/dashboard";
	}
	
	
	
	
}
