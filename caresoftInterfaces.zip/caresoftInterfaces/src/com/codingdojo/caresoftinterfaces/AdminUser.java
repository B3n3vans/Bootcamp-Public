package com.codingdojo.caresoftinterfaces;

import java.util.ArrayList;
import java.util.Date;

public class AdminUser extends User implements HIPAACompliantAdmin, HIPAACompliantUser {
//... imports class definition...
	private Integer employeeID;
    private String role;
    public ArrayList<String> securityIncidents;
    
    public AdminUser(int employeeID,int pin, String role) {
		super(employeeID,pin);
		this.role = role;
		this.securityIncidents = new ArrayList<String>();
//		this.securityIncidents = securityIncidents;
		// TODO Auto-generated constructor stub
	}
	// Inside class:
    
    
    // TO DO: Implement a constructor that takes an ID and a role
    // TO DO: Implement HIPAACompliantUser!
    // TO DO: Implement HIPAACompliantAdmin!
    
    public void newIncident(String notes) {
        String report = String.format(
            "Datetime Submitted: %s \n,  Reported By ID: %s\n Notes: %s \n", 
            new Date(), this.id, notes
        );
        securityIncidents.add(report);
    }
    public void authIncident() {
        String report = String.format(
            "Datetime Submitted: %s \n,  ID: %s\n Notes: %s \n", 
            new Date(), this.id, "AUTHORIZATION ATTEMPT FAILED FOR THIS USER"
        );
        securityIncidents.add(report);
    }
	@Override
	public boolean assignPin(int pin) {
		// TODO Auto-generated method stub
	    int length = (int)(Math.log10(pin)+1);
		if (length < 6) {
			return false;
		}else {
			super.setPin(pin);
			return true;
		}
	}
	public ArrayList<String> getSecurityIncidents() {
		return securityIncidents;
	}



	@Override
	public boolean accessAuthorized(Integer confirmedAuthID) {
		// TODO Auto-generated method stub
		if (this.id == confirmedAuthID) {
			return true;
		}else {
			authIncident();
			return false;
		}
	}
	@Override
	public ArrayList<String> reportSecurityIncidents() {
		// TODO Auto-generated method stub
		for (int i =0; i<securityIncidents.size();i++) {
			System.out.println(securityIncidents.get(i));
		}
		return null;
	}
}
