/**
 * 
 */
/**
 * @author b3n3v
 *
 */
module caresoftInterfaces {
}