// import Form from './form'
import React from 'react'

const Box = (props) => {
  const {color} = props
  return (
    <div className='box' style={{backgroundColor:color}}>
        <p>{color} </p>
    </div>
  )
}

export default Box