// import Box from './components/box.jsx';
import React , {useState} from 'react'
import BoxSection from './boxSection'

const Form = () => {
    const [color, setColor] = useState('')
    const [colors, setColors] = useState([])




    
    


    const handleForm = e => {
        e.preventDefault()
        setColor(e.target.value);
        colors.push(color)
    }

  return (
    <div>
        <form onSubmit={handleForm}>
            <label >Color: </label>
            <input onChange={(e)=>{setColor(e.target.value)}} type="text" name="color" id="" /><br/>
            <button type="submit">Add</button>
        </form>
        <h1>{color}</h1>
        <BoxSection colors={colors}/>
    </div>
  )
}

export default Form