import React from 'react'
import Box from './box'

const BoxSection = (props) => {
    const {colors} = props;


  return (
    <div className='BoxSection flex'>
        <ul className='flex'>
          {colors.map((color)=>(
            <Box color = {color}/>
          ))}
        </ul>
    </div>
  )
}

export default BoxSection