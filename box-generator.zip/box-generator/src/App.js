// import Box from './components/box.jsx';
// import BoxSection from './components/boxSection.jsx';
import Form from './components/form.jsx';
import './App.css';

function App() {
  return (
    <div className="App">
      <Form />
      {/* <Box/> */}
    </div>
  );
}

export default App;
