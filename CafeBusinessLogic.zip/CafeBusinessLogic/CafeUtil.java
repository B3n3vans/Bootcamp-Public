// package CafeBusinessLogic;
import java.util.ArrayList;

public class CafeUtil {
    

    public Integer getStreakGoal(int numWeeks) {
        int sum = 0;
        for (int i = 1; i<=numWeeks; i++){
            sum += i;
        }
        return sum;
    }

    public Double getOrderTotal(double[] prices){
        double sum = 0;
        for (int i = 0; i<prices.length;i++){
            sum += prices[i];
        }return sum;
    }
    public void displayMenu(ArrayList<String> menuItems){
        for (int i = 0;i<menuItems.size();i++){
            System.out.println(i +" "+ menuItems.get(i));
        }
    }
    // public String addCustomer(ArrayList<String> customers){
    //     System.out.println("Please Enter Your Name:");
    //     String userName = System.console().readLine();
    //     System.out.println("Hello "+ userName);
    //     System.out.println("There are "+ customers.size() + " people in front of you.");
    //     customers.add(userName);
    // }
    
    public void printPriceChart(String product, double price, int maxQuantity){
        System.out.println(product);
        for (int i =0;i<maxQuantity;i++){
            System.out.println((i+1)+" - $" + (price * (i+1)));
        }
    } 
}
